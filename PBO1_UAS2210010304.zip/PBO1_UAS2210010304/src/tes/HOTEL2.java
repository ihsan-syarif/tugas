package tes;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class HOTEL2 {
    public static void main(String[] args) {
      
        //error handling (try)
        try {
            //io sederhana
            Scanner scanner = new Scanner(System.in);
            List<HOTEL1> data = new ArrayList<>();
            boolean continueInput = true;

            // input nik, nama, type kamar
            // ARRAY
            while (continueInput) {
                System.out.print("Ketikan Nik Customer: "); // FORMAT NIK TAHUN,BULAN,TANGGAL
                // Contoh 21 04 001,002,003 dst sampai 999
                String nik = scanner.nextLine();
                System.out.print("Ketikan Nama Customer: ");
                String nama = scanner.nextLine();
                System.out.print("Ketikkan Type kamar Customer: "); // Contoh kamar (VIP1, VIP2, ELITE)
                String type = scanner.nextLine();
                System.out.println();

                // Objek nama customer HOTEL1
                HOTEL1 customer = new HOTEL1(nik, nama, type);
                data.add(customer);

                // Perulangan pilihan untuk menambahkan kostomer atau tidak
                System.out.print("Anda ingin menambahkan customer lain? (yes/no): ");
                String response = scanner.nextLine();
                if (!response.equalsIgnoreCase("yes")) {
                    continueInput = false;
                }
            }

            for (HOTEL1 member : data) {
                System.out.println(member.displayInfo());
            }

            // Error handling suatu kesalahan penginputan maka kode tidak akan jalan seperti semstinya
            scanner.close();
        } catch (NumberFormatException e) {
            System.out.println("Ada kesalahan format nik: " + e.getMessage());
        } catch (StringIndexOutOfBoundsException e) {
            System.out.println("Ada kesalahan format nama: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Ada kesalahan type abnormal: " + e.getMessage());
        }
    }
}
